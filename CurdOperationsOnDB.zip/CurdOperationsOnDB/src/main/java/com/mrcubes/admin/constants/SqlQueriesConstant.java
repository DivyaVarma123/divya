package com.mrcubes.admin.constants;

public class SqlQueriesConstant {

	public static final String INSERT_USER="insert into Employee() value(?,?,?,?,?,?)";
	public static final String SELECT_USER="select * from Employee";
	public static final String SELECT_USER_BY_ID="select * from employee where empId=?";
	public static final String UPDATE_USER="";
	
	
	
}
