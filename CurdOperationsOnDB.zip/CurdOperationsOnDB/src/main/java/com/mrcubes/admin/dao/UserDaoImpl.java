package com.mrcubes.admin.dao;

import java.util.List;

public class UserDaoImpl implements UserDao {

	public void AddUser() {

		
		
		
	}

	public List getAllUsers() {
		return null;
	}

	public void updateUser() {

	}

	public List listUsers() {
		return null;
	}

	public String getUsersById(int userId) {
		return null;
	}

}
