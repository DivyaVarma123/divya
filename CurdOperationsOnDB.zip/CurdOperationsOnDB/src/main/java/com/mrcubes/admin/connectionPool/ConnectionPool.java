package com.mrcubes.admin.connectionPool;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.logging.log4j.LogManager;
import org.apache.tomcat.jdbc.pool.PoolProperties;
import org.skife.jdbi.v2.DBI;
import org.skife.jdbi.v2.Handle;

import com.mrcubes.admin.exception.FunctionalRuntimeException;


public class ConnectionPool {
	private static final org.apache.logging.log4j.Logger logger= LogManager.getLogger("LogInServlet.class");
		
	public Handle getConnection() {
		 Handle h=null;
		 DataSource ds=null;
		 try  {
             String sql="select jdbcUrl,userName,password from tenants where tenantId=1";
			 DBI dbi = new DBI(sql);
              h = dbi.open(ds); 
		 }catch(FunctionalRuntimeException fe) {
			 fe.printStackTrace();
		 }
             
	 /*private static DataSource masterDatasource = null;
	    private static Map<String, DataSource> dataSourceMap = new HashMap<String, DataSource>();
	    private static Map<String, DataSource> auditDataSourceMap = new HashMap<String, DataSource>();

	    // db connection params to be read from master db
	   // private static void createPool(String tenantId) {
	        logger.info("createPool called for tenantId: {}", tenantId);
	        if (dataSourceMap.get(tenantId) == null) {
	            // Fetch url, username, password from master db.
	            Connection con = null;
	            ResultSet rs = null;
	            String dbUsername = null;
	            String dbPassword = null;
	            String jdbcUrl = null;

	            try {
	                con = ConnectionPool.getConnection();
	                String qry = "SELECT dbUsername, dbPassword, jdbcUrl FROM tenants WHERE id = ?";
	                PreparedStatement ps = con.prepareStatement(qry);
	                ps.setInt(1, Integer.parseInt(tenantId));
	                logger.info("createAuditPool: Going to execute query: {}.\nParams: {}", qry, tenantId);
	                rs = ps.executeQuery();
	                if (rs.next()) {
	                    dbUsername = rs.getString(1);
	                    dbPassword = rs.getString(2);
	                    jdbcUrl = rs.getString(3);
	                   logger.debug("createAuditPool: connection details retrieved. JdbcUrl mapped to this tenant is : {}", jdbcUrl);
	                } else {
	                    logger.error("createAuditPool: No tenant found matching to this tenant Id !!");
	                }
	                rs.close();
	            } catch (Exception e) {
	               logger.error("getTenantIdFrmUrl: Exception", e);
	            } finally {
	                if (con != null) {
	                    MultiTenantDBConnectionPool.returnConnection(con);
	                    con = null;
	                }
	            }

	            if (dbUsername != null) {
	                PoolProperties p = new PoolProperties();
	                p.setUrl(jdbcUrl);
	                p.setDriverClassName("com.mysql.jdbc.Driver");
	                p.setUsername(dbUsername);
	                p.setPassword(dbPassword);
	                p.setJmxEnabled(true);
	                p.setTestWhileIdle(false);
	                p.setTestOnBorrow(true);
	                p.setValidationQuery("SELECT 1");
	                p.setTestOnReturn(false);
	                p.setValidationInterval(30000);
	                p.setTimeBetweenEvictionRunsMillis(30000);
	                p.setMaxActive(10);
	                p.setInitialSize(2);
	                p.setMaxWait(10000);
	                p.setRemoveAbandonedTimeout(60);
	                p.setMinEvictableIdleTimeMillis(30000);
	                p.setMinIdle(1);
	                p.setLogAbandoned(true);
	                p.setRemoveAbandoned(true);
	                p.setJdbcInterceptors(
	                        "org.apache.tomcat.jdbc.pool.interceptor.ConnectionState;" + "org.apache.tomcat.jdbc.pool.interceptor.StatementFinalizer");
	                DataSource datasource = new DataSource();
	                datasource.setPoolProperties(p);
	                dataSourceMap.put(tenantId, datasource);
	            }
	        } else {
	            logger.error("createPool : DB CONNECTION LEAK !!! pool was already present for this tenant id: {}", tenantId);
	        }
	    }
  
             
    
     } 
     catch (Exception e) {
         e.printStackTrace();
     }
		 return h;  
	}
	
	*/
}
